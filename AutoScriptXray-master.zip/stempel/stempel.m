stempel saja
